package com.wasfat.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WasfatTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App()
                }
            }
        }
    }
}

private const val PREFS = "wasfat"
private const val KEY_FAVS = "favorites"

private fun loadFavs(ctx: Context): Set<Int> =
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getStringSet(KEY_FAVS, emptySet())
        .orEmpty()
        .mapNotNull { it.toIntOrNull() }
        .toSet()

private fun saveFavs(ctx: Context, favs: Set<Int>) {
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit()
        .putStringSet(KEY_FAVS, favs.map { it.toString() }.toSet())
        .apply()
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var favs by remember { mutableStateOf(loadFavs(ctx)) }
    var openId by rememberSaveable { mutableStateOf<Int?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var catIndex by rememberSaveable { mutableIntStateOf(-1) }
    var onlyFav by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()

    BackHandler(enabled = openId != null) { openId = null }

    val current = RECIPES.firstOrNull { it.id == openId }
    if (current == null) {
        HomeScreen(
            favs = favs,
            query = query,
            onQuery = { query = it },
            catIndex = catIndex,
            onlyFav = onlyFav,
            onFilter = { c, f ->
                catIndex = c
                onlyFav = f
            },
            listState = listState,
            onOpen = { openId = it.id }
        )
    } else {
        DetailScreen(
            r = current,
            fav = current.id in favs,
            onBack = { openId = null },
            onToggleFav = {
                favs = if (current.id in favs) favs - current.id else favs + current.id
                saveFavs(ctx, favs)
            }
        )
    }
}
