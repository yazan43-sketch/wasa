package com.wasfat.app

enum class Category(val label: String) {
    GULF("خليجية"),
    ARAB("عربية"),
    WORLD("عالمية"),
    SWEETS("حلويات"),
    DRINKS("مشروبات")
}

data class Recipe(
    val id: Int,
    val name: String,
    val category: Category,
    val minutes: Int,
    val servings: Int,
    val level: String,
    val intro: String,
    val ingredients: List<String>,
    val steps: List<String>
)
