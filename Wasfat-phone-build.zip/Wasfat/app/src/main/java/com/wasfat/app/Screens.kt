@file:OptIn(ExperimentalMaterial3Api::class)

package com.wasfat.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private val HeartRed = Color(0xFFC0392B)

@Composable
fun HomeScreen(
    favs: Set<Int>,
    query: String,
    onQuery: (String) -> Unit,
    catIndex: Int,
    onlyFav: Boolean,
    onFilter: (Int, Boolean) -> Unit,
    listState: LazyListState,
    onOpen: (Recipe) -> Unit
) {
    val cats = Category.values()
    val cat = cats.getOrNull(catIndex)
    val q = query.trim()
    val shown = RECIPES.filter { r ->
        (cat == null || r.category == cat) &&
            (!onlyFav || r.id in favs) &&
            (q.isEmpty() || r.name.contains(q) || r.ingredients.any { it.contains(q) })
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("وصفات", fontWeight = FontWeight.Bold) }) }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                placeholder = { Text("ابحث عن وصفة أو مكوّن") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = catIndex == -1 && !onlyFav,
                        onClick = { onFilter(-1, false) },
                        label = { Text("الكل") }
                    )
                }
                items(cats.size) { i ->
                    FilterChip(
                        selected = catIndex == i && !onlyFav,
                        onClick = { onFilter(i, false) },
                        label = { Text(cats[i].label) }
                    )
                }
                item {
                    FilterChip(
                        selected = onlyFav,
                        onClick = { onFilter(-1, true) },
                        label = { Text("المفضلة") }
                    )
                }
            }
            if (shown.isEmpty()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (onlyFav) "ما أضفت وصفات للمفضلة بعد. افتح أي وصفة واضغط القلب." else "ما لقينا وصفة مطابقة.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(shown, key = { it.id }) { r ->
                        RecipeCard(r, r.id in favs) { onOpen(r) }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecipeCard(r: Recipe, fav: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = r.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                if (fav) {
                    Icon(
                        Icons.Filled.Favorite,
                        contentDescription = "في المفضلة",
                        tint = HeartRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Text(
                text = r.intro,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${r.category.label} · ${r.minutes} دقيقة · تكفي ${r.servings} · ${r.level}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun DetailScreen(r: Recipe, fav: Boolean, onBack: () -> Unit, onToggleFav: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(r.name, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = onToggleFav) {
                        Icon(
                            Icons.Filled.Favorite,
                            contentDescription = if (fav) "إزالة من المفضلة" else "إضافة إلى المفضلة",
                            tint = if (fav) HeartRed else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${r.category.label} · ${r.minutes} دقيقة · تكفي ${r.servings} · ${r.level}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(r.intro, style = MaterialTheme.typography.bodyLarge)
                }
            }
            item { SectionTitle("المقادير") }
            items(r.ingredients) { line ->
                Text("• $line", style = MaterialTheme.typography.bodyLarge)
            }
            item { SectionTitle("طريقة التحضير") }
            itemsIndexed(r.steps) { i, step ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${i + 1}",
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    Text(step, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 12.dp)
    )
}
