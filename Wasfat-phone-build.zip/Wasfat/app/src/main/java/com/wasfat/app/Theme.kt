package com.wasfat.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF2F6B4F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDE8D8),
    onPrimaryContainer = Color(0xFF0B2A1B),
    secondary = Color(0xFF9A5B0E),
    secondaryContainer = Color(0xFFCDE8D8),
    onSecondaryContainer = Color(0xFF0B2A1B),
    background = Color(0xFFF4F6F3),
    onBackground = Color(0xFF181D1A),
    surface = Color(0xFFF4F6F3),
    onSurface = Color(0xFF181D1A),
    surfaceVariant = Color(0xFFE3EAE4),
    onSurfaceVariant = Color(0xFF3F4A43),
    outline = Color(0xFF727D75)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FD0AC),
    onPrimary = Color(0xFF00391F),
    primaryContainer = Color(0xFF1F4D36),
    onPrimaryContainer = Color(0xFFCDE8D8),
    secondary = Color(0xFFF0B968),
    secondaryContainer = Color(0xFF1F4D36),
    onSecondaryContainer = Color(0xFFCDE8D8),
    background = Color(0xFF111513),
    onBackground = Color(0xFFE2E6E3),
    surface = Color(0xFF111513),
    onSurface = Color(0xFFE2E6E3),
    surfaceVariant = Color(0xFF1F2823),
    onSurfaceVariant = Color(0xFFBFC9C1),
    outline = Color(0xFF8A958D)
)

@Composable
fun WasfatTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
